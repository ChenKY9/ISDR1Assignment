layui.use(['form','layer','table','laypage','util'],function(){
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer,
        $ = layui.jquery,
        util = layui.util,
        table = layui.table;
       laypage = layui.laypage;

    
    page=1;
    size =10;
    count=0; 
    data = [];
    input = "",
    //设置搜索条件 和分页数
    tableIns = null;
    queryData(page,size,input,true);
    function queryData(p,s,input,isRenderPage){
        $.post("/admin?action=query",{
            	"input":input,
            	"page":p,
            	"size":s
        },function(res){
                 res = JSON.parse(res)
            console.log(res)
        		if(res.code != 200){
        			layer.msg("server error");
        			return false;
        		}
    		     count  = res.data.count;
    		     data = res.data.data
    		    tableIns = table.render({
    		         elem: '#adminList',
    		         data:data,
    		         cellMinWidth : 95,
    		         height : "full-200",
    		         cols : [[
    		             {type: "checkbox", fixed:"left"},
                          {field: 'username', title: 'username', align:"center"},
                          {field: 'pwd', title: 'password', align:"center"},
                            {field: 'createTime', title: 'createTime', align:"center",templet:function(d){
			    		            	 return util.toDateString(new Date(d.createTime).getTime(), "yyyy-MM-dd HH:mm:ss");
			    		   }},			    		   
                            {field: 'updateTime', title: 'updateTime', align:"center",templet:function(d){
			    		            	 return util.toDateString(new Date(d.updateTime).getTime(), "yyyy-MM-dd HH:mm:ss");
			    		   }},
    		             {title: 'oper', templet:'#adminListBar',width:200,fixed:"right",align:"center"}
    		         ]]
    		     });
    		     if(isRenderPage){
    			     laypage.render({
     		    	    elem: 'page'
     		    	    ,count: count,
     		    	    limit:size,
                         // prev:"prev",
                         // next:"next",
     		    	   layout: ['count', 'prev', 'page', 'next', 'refresh', 'skip'],
     		    	    jump: function(obj, first){
     		    	        if(!first){
     		    	            page = obj.curr;
     		    	            size = obj.limit;
     		    	        	queryData(page,size,input,false);
     		    	        }
     		    	    }    
     		     });
    		     }
    	})
    }
    

    
   
    
    $(".search_btn").on("click",function(){
    	let val = $(".searchVal").val();
        if(val){
        	queryData(page,size,val,false);
        }else{
        	input = ""
        	queryData(page,size,input,false);
        }
    });

    function addAdmin(edit){
        var index = layui.layer.open({
            title : "add admin",
            type : 2,
            content : "/jump?action=toAdminAdd",
            end:function(){
              	 queryData(page,size,input,true);
               },
            success : function(layero, index){
                var body = layui.layer.getChildFrame('body', index);
                body.find(".edit").hide();
                if(edit){
               body.find("#id").val(edit.id);
               body.find("#username").val(edit.username);
               body.find("#pwd").val(edit.pwd);
                    
                    body.find(".edit").show();
                    body.find(".add").hide();
                    form.render();
                }
                setTimeout(function(){
                    layui.layer.tips('back admin list', '.layui-layer-setwin .layui-layer-close', {
                        tips: 3
                    });
                },500)
            }
        })
        layui.layer.full(index);
        window.sessionStorage.setItem("index",index);
        $(window).on("resize",function(){
            layui.layer.full(window.sessionStorage.getItem("index"));
        })
    }
    $(".addNews_btn").click(function(){
        addAdmin();
    })

    $(".delAll_btn").click(function(){
        var checkStatus = table.checkStatus('adminList'),
            data = checkStatus.data,
            newsId = [];
        if(data.length > 0) {
            for (var i in data) {
                newsId.push(data[i].id);
            }
            layer.confirm('Are you sure you want to delete the administrator？', {icon: 3, title: 'info'}, function (index) {
                 $.post("/admin?action=batchDelete",{
                	 ids:JSON.stringify(newsId)
                 },function(res){
                     res = JSON.parse(res);
                   	 if(res.code == 200){
                      	 queryData(page,size,input,true);
                         layer.close(index);
                         layer.msg("delete success");
                   	 }
                 })
            })
        }else{
            layer.msg("Please select the administrator account to delete");
        }
    })

    //列表操作
    table.on('tool(adminList)', function(obj){
        var layEvent = obj.event,
            data = obj.data;

        if(layEvent === 'edit'){ //编辑
            addAdmin(data);
        }
        else if(layEvent === 'del'){ //删除
             layer.confirm('Are you sure you want to delete this administrator account？',{icon:3, title:'info'},function(index){
                 $.get("/admin?action=delete",{
                     id : data.id
                 },function(res){
                     res = JSON.parse(res);
                	 if(res.code == 200){
                		 queryData(page,size,input,true);
                		 layer.msg("delete success");
                         layer.close(index);
                	 }
                 })
            });
        }
    });

})
