layui.use(['form', 'layer', 'laydate'], function () {
    var form = layui.form
    layer = parent.layer === undefined ? layui.layer : top.layer,
        laydate = layui.laydate,
        $ = layui.jquery;

    form.on("submit(addUser)", function (data) {
        var index = top.layer.msg('Data submission, please wait', {icon: 16, time: false, shade: 0.8});
        let name = $("#name").val()
        let phone = $("#phone").val()
        let address = $("#address").val()
        $.post("/user?action=add", {
            name: name,
            phone: phone,
            address: address,
        }, function (res) {
            res = JSON.parse(res);
            if (res.code == 200) {
                top.layer.msg("add sucess");
            } else {
                top.layer.msg(res.msg);
            }
            top.layer.close(index);
            layer.closeAll("iframe");
            //刷新父页面
            parent.location.reload();
        })

        return false;
    })

    form.on("submit(editUser)", function (data) {
        //弹出loading
        var index = top.layer.msg('Data submission, please wait', {icon: 16, time: false, shade: 0.8});
        let id = $("#id").val()
        let name = $("#name").val()
        let phone = $("#phone").val()
        let address = $("#address").val()

        $.post("/user?action=update", {
            id: id,
            name: name,
            phone: phone,
            address: address,
        }, function (res) {
            res = JSON.parse(res);
            if (res.code == 200) {
                top.layer.msg("edit success");
            } else {
                top.layer.msg(res.msg);
            }
            top.layer.close(index);
            layer.closeAll("iframe");
            //刷新父页面
            parent.location.reload();
        })
        return false;
    })

    //格式化时间
    function filterTime(val) {
        if (val < 10) {
            return "0" + val;
        } else {
            return val;
        }
    }

    //定时发布
    var time = new Date();
    var submitTime = time.getFullYear() + '-' + filterTime(time.getMonth() + 1) + '-' + filterTime(time.getDate()) + ' ' + filterTime(time.getHours()) + ':' + filterTime(time.getMinutes()) + ':' + filterTime(time.getSeconds());


})