layui.use(['form','layer','table','laypage','util'],function(){
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer,
        $ = layui.jquery,
        util = layui.util,
        table = layui.table;
       laypage = layui.laypage;

    
    page=1;
    size =10;
    count=0; 
    data = [];
    input = "",
    tableIns = null;
    queryData(page,size,input,true);
    function queryData(p,s,input,isRenderPage){
        $.post("/user?action=query",{
            	"input":input,
            	"page":p,
            	"size":s
        },function(res){
    		     console.log(res)
//    		     let res = JSON.parse(resStr)
            res = JSON.parse(res);
        		if(res.code != 200){
        			layer.msg("server error");
        			return false;
        		}
    		     count  = res.data.count;
    		     data = res.data.data
    		    tableIns = table.render({
    		         elem: '#userList',
    		         data:data,
    		         cellMinWidth : 95,
    		         height : "full-200",
    		         cols : [[
    		             {type: "checkbox", fixed:"left"},
                          {field: 'name', title: 'name', align:"center"},
                          {field: 'phone', title: 'phone', align:"center"},
                          {field: 'address', title: 'address', align:"center"},
                            {field: 'createTime', title: 'createTime', align:"center",templet:function(d){
			    		            	 return util.toDateString(new Date(d.createTime).getTime(), "yyyy-MM-dd HH:mm:ss");
			    		   }},			    		   
                            {field: 'updateTime', title: 'updateTime', align:"center",templet:function(d){
			    		            	 return util.toDateString(new Date(d.updateTime).getTime(), "yyyy-MM-dd HH:mm:ss");
			    		   }},			    		   
    		             {title: 'oper', templet:'#userListBar',width:200,fixed:"right",align:"center"}
    		         ]]
    		     });
    		     if(isRenderPage){
    			     laypage.render({
     		    	    elem: 'page'
     		    	    ,count: count,
     		    	    limit:size,
     		    	   layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip'],
     		    	    jump: function(obj, first){
     		    	        if(!first){
     		    	            page = obj.curr;
     		    	            size = obj.limit;
     		    	        	queryData(page,size,input,false);
     		    	        }
     		    	    }    
     		     });
    		     }
    	})
    }
    

    
   
    
    $(".search_btn").on("click",function(){
    	let val = $(".searchVal").val();
        if(val){
        	queryData(page,size,val,false);
        }else{
        	input = ""
        	queryData(page,size,input,false);
        }
    });

    function addUser(edit){
        var index = layui.layer.open({
            title : "add user",
            type : 2,
            content : "/jump?action=toUserAdd",
            end:function(){
              	 queryData(page,size,input,true);
               },
            success : function(layero, index){
                var body = layui.layer.getChildFrame('body', index);
//                console.log(edit);
                body.find(".edit").hide();
                if(edit){
               body.find("#id").val(edit.id);
               body.find("#name").val(edit.name);
               body.find("#phone").val(edit.phone);
               body.find("#address").val(edit.address);
                    
                    body.find(".edit").show();
                    body.find(".add").hide();
                    form.render();
                }
                setTimeout(function(){
                    layui.layer.tips('back user list', '.layui-layer-setwin .layui-layer-close', {
                        tips: 3
                    });
                },500)
            }
        })
        layui.layer.full(index);
        window.sessionStorage.setItem("index",index);
        $(window).on("resize",function(){
            layui.layer.full(window.sessionStorage.getItem("index"));
        })
    }
    $(".addNews_btn").click(function(){
        addUser();
    })

    $(".delAll_btn").click(function(){
        var checkStatus = table.checkStatus('userList'),
            data = checkStatus.data,
            newsId = [];
        if(data.length > 0) {
            for (var i in data) {
                newsId.push(data[i].id);
            }
            layer.confirm('delete user？', {icon: 3, title: 'info'}, function (index) {
                 $.post("/user?action=batchDelete",{
                	 ids:JSON.stringify(newsId)
                 },function(res){
                     res = JSON.parse(res);
                   	 if(res.code == 200){
                      	 queryData(page,size,input,true);
                         layer.close(index);
                         layer.msg("delete success");
                   	 }
                 })
            })
        }else{
            layer.msg("Please select the user account to delete");
        }
    })

    table.on('tool(userList)', function(obj){
        var layEvent = obj.event,
            data = obj.data;

        if(layEvent === 'edit'){
            addUser(data);
        }
        else if(layEvent === 'del'){
             layer.confirm('Are you sure you want to delete this user account？',{icon:3, title:'info'},function(index){
                 $.get("/user?action=delete",{
                     id : data.id
                 },function(res){
                     res = JSON.parse(res);
                	 if(res.code == 200){
                		 queryData(page,size,input,true);
                		 layer.msg("delete success");
                         layer.close(index);
                	 }
                 })
            });
        }
    });

})
