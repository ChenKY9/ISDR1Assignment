layui.use(['form','layer','jquery'],function(){
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer
        $ = layui.jquery;
     $img = $("#imgCode img");
     $img.click(()=>{
    	 $img[0].src = '/util?action=code&ticket='+ Math.random();
     });
    
    $(".loginBody .seraph").click(function(){
        layer.msg("这只是做个样式，至于功能，你见过哪个后台能这样登录的？还是老老实实的找管理员去注册吧",{
            time:5000
        });
    })
    
    $("#login").click(function(){
    	  $(this).text("login...").attr("disabled","disabled");
          username = $("#username").val()
          password = $("#password").val()
          code = $("#code").val()
          if(!username){
         	 layer.msg("please input username",{
                  time:5000
              });
         	 $(this).text("login").attr("disabled",false);
         	 return false;
          }
          if(!password){
         	 layer.msg("please input password",{
                  time:5000
              });
         	 $(this).text("login").attr("disabled",false);
         	 return false;
          }
          if(!code){
         	 layer.msg("please input Verification Code",{
                  time:5000
              });
         	 $(this).text("login").attr("disabled",false);
         	 return false;
          }
          setTimeout(() => {
        		$.post('/login',{
        				  name:username,
        				  pwd:password,
                          code:code
        		},function(result){
        		    result = JSON.parse(result);
        			if(result.code == 200){
        				 window.location.href = "/jump?action=toIndex";
        				 localStorage.setItem("admin",JSON.stringify(result.data))
        			}else{
        				layer.msg(result.msg);
        				$("#login").text("login").attr("disabled",false);
        			}
        		});
		}, 1000);
          
    });

    $(".loginBody .input-item").click(function(e){
        e.stopPropagation();
        $(this).addClass("layui-input-focus").find(".layui-input").focus();
    })
    $(".loginBody .layui-form-item .layui-input").focus(function(){
        $(this).parent().addClass("layui-input-focus");
    })
    $(".loginBody .layui-form-item .layui-input").blur(function(){
        $(this).parent().removeClass("layui-input-focus");
        if($(this).val() != ''){
            $(this).parent().addClass("layui-input-active");
        }else{
            $(this).parent().removeClass("layui-input-active");
        }
    })
})
