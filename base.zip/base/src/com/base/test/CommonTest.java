package com.base.test;

import com.base.util.MysqlDbs;

import java.sql.Connection;

public class CommonTest {


    public static void main(String[] args) {
    }

    public static void testDbsConn(){
        Connection conn = MysqlDbs.getConn();
        System.out.println(conn);
    }
}
