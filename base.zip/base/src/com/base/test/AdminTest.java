package com.base.test;

import com.base.bean.Admin;
import com.base.dao.AdminDao;
import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

public class AdminTest {

    static AdminDao dao = new AdminDao();

    public static void main(String[] args) {
//        testAdd();
//        testUpdate();
//        testQuery();
//        testDelete();
//        for (int i = 0; i < 10; i++) {
//            testAdd();
//        }
//        testQueryPage();
//        testQueryOne();
        testQueryCount();
    }


    public static void testQueryCount() {
        String sql = "select count(1) from admin";
        long count = dao.queryCount(sql);
        System.out.println(count);

    }

    public static void testQueryOne() {
        Admin admin = new Admin();
        admin.setUsername("asd");
        admin.setPwd("123456");
        Admin o = dao.queryOne(admin);
        System.out.println(o);
    }

    public static void testQueryPage() {
        dao.query("", 1, 5);
//        System.out.println(admins);
    }

    public static void testDelete() {
        dao.delete(1L);
    }


    public static void testUpdate() {
        Admin admin = new Admin();
        admin.setId(1L);
        ;
        admin.setUsername("那是的");
        admin.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
        dao.update(admin);
    }

    public static void testQuery() {
        Admin admin = dao.queryById(1L);
        System.out.println(admin);
    }

    public static void testAdd() {
        Admin admin = new Admin();
        admin.setUsername("test");
        admin.setPwd("123456");
        admin.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
        admin.setUpdateTime(Timestamp.valueOf(LocalDateTime.now()));
        dao.add(admin);
        System.out.println("插入成功");
    }
}
