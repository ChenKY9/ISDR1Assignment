package com.base.test;

import com.base.bean.Account;
import com.base.dao.AccountDao;

public class AccountTest {
    static AccountDao dao = new AccountDao();

    public static void main(String[] args) {
        testAdd();
//        testUpdate();
    }


    public static void testAdd(){
        Account account = new Account();
        account.setName("test");
        dao.add(account);
    }


}
