package com.base.dao;

import com.base.bean.Admin;
import com.base.util.Strings;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminDao extends  Dao<Admin> {



    public Map<String,Object> query(String input, Integer page, Integer size){
        String sql = "select * from admin";
        if(!Strings.isEmpty(input)){
            sql += " where username like '%" + input+"%'";
        }

        List<Admin> admins = queryPage(sql, page, size);
        sql = "select count(1) from admin";
        if(!Strings.isEmpty(input)){
            sql += " where username like '%" + input+"%'";
        }

        long count = queryCount(sql);
        Map<String,Object> map = new HashMap<>();
        map.put("data",admins);
        map.put("count",count);
        return  map;
    }




}
