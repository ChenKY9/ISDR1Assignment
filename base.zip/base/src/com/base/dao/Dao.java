package com.base.dao;

import com.base.util.DerbyDbs;
import com.base.util.MysqlDbs;
import com.base.util.Refs;
import com.base.util.Strings;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * jdbc 通用操作数据库操作封装
 * 增删改查
 * 不要用 关键字给字段 起名 prestament 会自动过滤
 *
 * @param <T>
 * @author admin
 */
public class Dao<T> {

    // t的泛型操作
    private Class<T> clz = null;

    //	private Connection conn = MysqlDbs.getConn();
//    private Connection conn = DerbyDbs.getConn();
    private Connection conn = DerbyDbs.getWebConn();

    private PreparedStatement ps = null;

    private ResultSet rs = null;

    //是否启动驼峰转下换线
    private boolean isHump = true;

    public Dao() {
        // 获取应用时 UserDao extend Dao<User> 的泛型实体类 User
        Type type = this.getClass().getGenericSuperclass();
        ParameterizedType p = (ParameterizedType) type;
        clz = (Class<T>) p.getActualTypeArguments()[0];
    }

    public T queryById(Long id) {
        T obj = null;
        try {
            obj = clz.newInstance();
            String sql = "select * from " + Strings.f2L(clz.getSimpleName()) + " where id=?";
            ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            rs = ps.executeQuery();
            ResultSetMetaData md = rs.getMetaData();
            int c = md.getColumnCount();
            Field[] fields = Refs.getAllFieldsArr(clz);
            while (rs.next()) {
                setObj(obj, md, c, fields);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MysqlDbs.close(rs, ps);
        }
        return obj;
    }


    public T queryOne(T t){
        T obj = null;
        int rowCount = 0;
        try {
            String sql = "select * from " + Strings.f2L(clz.getSimpleName());
            Field[] fields = Refs.getAllFieldsArr(clz);
            List<Object> vals = new ArrayList<>();
            String conditon = "";
            for (Field f : fields) {
                f.setAccessible(true);
                Object val = f.get(t);
                if(val!=null){
                    vals.add(val);
                    conditon+= getColumnName(f)+"=? and ";
                }
            }
            if(!"".equals(conditon)){
                conditon = conditon.substring(0,conditon.length()-4);
                sql +=" where "+conditon;
            }
            System.out.println(sql);
            ps = conn.prepareStatement(sql);
            if(vals.size()>0){
                for (int i = 0; i < vals.size(); i++) {
                     ps.setObject(i+1,vals.get(i));
                }
            }
            rs = ps.executeQuery();
            ResultSetMetaData md = rs.getMetaData();
            int c = md.getColumnCount();
            obj = clz.newInstance();
            rowCount = 0;
            while (rs.next()) {
                rowCount ++;
                setObj(obj, md, c, fields);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MysqlDbs.close(rs, ps);
        }
        return  rowCount == 0 ? null:obj;
    }

    public T queryOneBySql(String sql){
          T obj = null;
        try {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            ResultSetMetaData md = rs.getMetaData();
            int c = md.getColumnCount();
            obj = clz.newInstance();
            Field[] fields = Refs.getAllFieldsArr(clz);
            while (rs.next()) {
                setObj(obj, md, c, fields);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MysqlDbs.close(rs, ps);
        }
          return  obj;
    }


    public long queryCount(String sql){
        long count = 0;
        try {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            ResultSetMetaData md = rs.getMetaData();
            while (rs.next()) {
                count = rs.getLong(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MysqlDbs.close(rs, ps);
        }
        return  count;
    }


    public List<T> queryPage(String sql, Integer page, Integer size) {
//        sql += " limit " + (page - 1) * size + "," + page * size;
        sql += " OFFSET " + (page - 1) * size + " ROWS FETCH NEXT " + page * size +" ROWS ONLY";
        List<T> list = new ArrayList();
        System.out.println(sql);
        try {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            ResultSetMetaData md = rs.getMetaData();
            int c = md.getColumnCount();
            Field[] fields = Refs.getAllFieldsArr(clz);
            while (rs.next()) {
                T obj = clz.newInstance();
                setObj(obj, md, c, fields);
                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MysqlDbs.close(rs, ps);
        }
        return list;
    }

    public boolean delete(Long id) {
        String sql = "delete  from " + Strings.f2L(clz.getSimpleName()) + " where id=?";
        try {
            ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            ps.execute();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MysqlDbs.close(ps);
        }
        return false;
    }

    public boolean add(T t) {
        Field[] fields = Refs.getAllFieldsArr(clz);
        String b_sql = "insert into " + Strings.f2L(clz.getSimpleName()) + "(";
        String a_sql = " values(";
        List<Object> list = new ArrayList<Object>();
        try {
            for (Field f : fields) {
                f.setAccessible(true);
                Object val = f.get(t);
                if (val != null) {
                    b_sql += getColumnName(f) + ",";
                    a_sql += "?,";
                    list.add(val);
                }
            }
            b_sql = b_sql.substring(0, b_sql.length() - 1) + ")";
            a_sql = a_sql.substring(0, a_sql.length() - 1) + ")";
            String sql = b_sql + a_sql;
            ps = conn.prepareStatement(sql);
            for (int i = 0, size = list.size(); i < size; i++) {
                Object obj = list.get(i);
                ps.setObject(i + 1, obj);
            }
            ps.execute();
            return true;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            MysqlDbs.close(ps);
        }
        return false;
    }

    private String getColumnName(Field f) {
        String name = f.getName();
        if (isHump) { // 开启驼峰转下划线
            return Strings.hump2Breaking(name);
        }
        return name;
    }

    public boolean update(T t) {
        Field[] fields = Refs.getAllFieldsArr(clz);
        String sql = "update " + Strings.f2L(clz.getSimpleName()) + " set ";
        List<Object> list = new ArrayList<Object>();
        try {
            Object idVal = null;
            for (Field f : fields) {
                f.setAccessible(true);
                Object val = f.get(t);
                if (f.getName() == "id") {
                    idVal = val;
                    continue;
                }
                if (val != null) {
                    sql += getColumnName(f) + "=?,";
                    list.add(val);
                }
            }
            sql = sql.substring(0, sql.length() - 1);
            sql += " where id=?";
            ps = conn.prepareStatement(sql);
            int size = list.size();
            for (int i = 0; i < size; i++) {
                Object obj = list.get(i);
                ps.setObject(i + 1, obj);
            }
            ps.setObject(size + 1, idVal);
            ps.execute();
            return true;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            MysqlDbs.close(ps);
        }
        return false;
    }

    // 将结果集和对象的值匹配
    private void setObj(T obj, ResultSetMetaData md, int c, Field[] fields)
            throws SQLException, IllegalAccessException {
        for (int i = 1; i <= c; i++) {
            String ln = md.getColumnLabel(i);
            // 设置对应对象里面的对应属性
            for (Field f : fields) {
                f.setAccessible(true);
                if (f.getName().equals(ln) || f.getName().equals(Strings.lineToHump(ln))) {
                    String tn = f.getType().getSimpleName();
//                    System.out.println(tn);
                    if (tn.equals("String")) {
                        f.set(obj, rs.getString(ln));
                    } else if (tn.equals("Integer")) {
                        f.set(obj, rs.getInt(ln));
                    } else if (tn.equals("Long")) {
                        f.set(obj, rs.getLong(ln));
                    } else if (tn.equals("Date")) {
                        Time time = rs.getTime(ln);
                        if (time != null) {
                            f.set(obj, new Date(time.getTime()));
                        }
                    }else if (tn.equals("Timestamp")){
                        Timestamp timestamp = rs.getTimestamp(ln);
                        if(timestamp !=null){
                              f.set(obj,timestamp);
                        }
                    }
                    break;
                }
            }
        }
    }


    public static void main(String[] args) {

    }

}
