package com.base.dao;

import com.base.bean.Account;
import com.base.bean.Admin;
import com.base.util.Strings;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AccountDao extends Dao<Account> {



    public Map<String,Object> query(String input, Integer page, Integer size){
        String sql = "select * from account";
        if(!Strings.isEmpty(input)){
            sql += " where name like '%" + input+"%' or phone like '%"+input+"%'";
        }

        List<Account> accounts = queryPage(sql, page, size);
        sql = "select count(1) from account";
        if(!Strings.isEmpty(input)){
            sql += " where name like '%" + input+"%' or phone like '%"+input+"%'";
        }

        long count = queryCount(sql);
        Map<String,Object> map = new HashMap<>();
        map.put("data",accounts);
        map.put("count",count);
        return  map;
    }



}
