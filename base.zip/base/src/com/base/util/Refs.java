package com.base.util;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 反射工具集
 * 以及操作反射生成代码
 * 各种生成代码
 *
 * @author admin
 */
public class Refs {

    //全局使用的字节码,当前操作的字节码对象
    private static Class clz = null;

    public static List<Field> getFields(Class c) {
        return getFields(c, getCommonFilterField());
    }

    public static List<Field> getFields(Class c, String... filterFields) {
        clz = c;
        Field[] fields = c.getDeclaredFields();
        List<Field> list = new ArrayList<Field>();
        for (Field f : fields) {
            boolean filter = false;
            for (String fN : filterFields) {
                if (f.getName().equals(fN)) {
                    filter = true;
                    break;
                }
            }
            if (!filter) {
                list.add(f);
            }
        }
        return list;
    }

    public static Field[] getAllFieldsArr(Class c){
        List<Field> arr = getAllFields(c);
        return arr.toArray(new Field[arr.size()]);
    }

	public static List<Field> getAllFields(Class c) {
		return getAllFields(c, getCommonFilterField());
	}

    public static List<Field> getAllFields(Class c, String... filterFields) {
        List<Field> list = new ArrayList<Field>();
        while (c != null) {
            Field[] fields = c.getDeclaredFields();
            for (Field f : fields) {
                boolean filter = false;
                for (String fN : filterFields) {
                    if (f.getName().equals(fN)) {
                        filter = true;
                        break;
                    }
                }
                if (!filter) {
                    list.add(f);
                }
            }
            c = c.getSuperclass();
        }
        return list;
    }


    public static String[] getCommonFilterField() {
        return new String[]{"serialVersionUID"};
    }

    /**
     * 获取父类的泛型参数化类型
     * Studnet extend Person<User>
     * 获取的是User.class
     *
     * @param clz
     * @return
     */
    //Type是 Java 编程语言中所有类型的公共高级接口。它们包括原始类型、参数化类型、数组类型、类型变量和基本类型。
    public Class getGenericClass(Class clz) {
        Type type = clz.getGenericSuperclass();
        //ParameterizedType参数化类型，即泛型
        ParameterizedType p = (ParameterizedType) type;
        return (Class) p.getActualTypeArguments()[0];
    }



}
