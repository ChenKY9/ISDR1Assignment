package com.base.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

/**
 *   时间工具类 老版本
 * @author admin
 *
 */
public class DateOlds {
	
	private final static String pattern = "yyyy-MM-dd HH:mm:ss";
	
	private final static  DateFormat dfm  = new SimpleDateFormat(pattern);
	
	
	public static String formatDate(Date date) {
		  if(date ==null) {
			   return "";
		   }
		  return dfm.format(date);
	}
	
	public static String formatDate(Date date,String pattern) {
		  return new SimpleDateFormat(pattern).format(date);
	}
	
	public static Date parse(String date)  {
		  try {
			 return dfm.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		 return null;
	}
	
	public static String nowStr() {
		 return formatDate(new Date());
	}
	
	
	public static String nowStr(String pattern) {
		 return formatDate(new Date(),pattern);
	}


	public static void main(String[] args) {
		System.out.println(Timestamp.valueOf(LocalDateTime.now()));
	}
	
	
	
	
	

}
