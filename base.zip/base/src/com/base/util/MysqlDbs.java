package com.base.util;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;


public class MysqlDbs {

	private static String driver = "com.mysql.jdbc.Driver";// MySql驱动
	private static String url = "jdbc:mysql://localhost:3306/test";
	private static String user = "root";// 用户名
	private static String password = "123456";// 密码

	private static Connection conn = null;

	
//	static {
//		Properties pro = new Properties();
//		FileInputStream fi = null;
//		try {
//			fi = new FileInputStream(new File("src/db.properties"));
//			pro.load(fi);
//			driver = pro.getProperty("driver","com.mysql.jdbc.Driver");
//			url = pro.getProperty("url","jdbc:mysql://localhost:3306/test");
//			user = pro.getProperty("user","root");
//			password = pro.getProperty("password","123456");
//
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}finally {
//			close(fi);
//		}
//	}
	
	
	public static Connection getConn() {
		if (conn == null) {
			try {
				// 尝试建立到给定数据库URL的连接
				Class.forName(driver);// 动态加载类
				conn = DriverManager.getConnection(url, user, password);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return conn;
	}

	public static void close(AutoCloseable... closes) {
		for (AutoCloseable c : closes) {
			if (c != null) {
				try {
					c.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	
	public static void main(String[] args) {
		    MysqlDbs dbs = new MysqlDbs();
	        System.out.println(dbs);	
	}

	@Override
	public String toString() {
		return "url:"+url+"\ndriver:"+driver+"\nuser:"+user+"\npassword:"+password;
	}
	
	
	
	
}
