package com.base.util;

import java.io.File;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DerbyDbs {
      static  String createAdmin = "CREATE TABLE admin(\n" +
              "  id int NOT NULL GENERATED ALWAYS AS IDENTITY ,\n" +
              "  username varchar(255)  DEFAULT NULL ,\n" +
              "  pwd varchar(255)  DEFAULT NULL,\n" +
              "  create_time TIMESTAMP ,\n" +
              "  update_time TIMESTAMP" +
              ") ";

      static String createUser = "CREATE TABLE account (\n" +
              "  id int NOT NULL GENERATED ALWAYS AS IDENTITY ,\n" +
              "  name varchar(255) ,\n" +
              "  phone varchar(255) , \n" +
              "  address varchar(255) ,\n" +
              "  create_time TIMESTAMP,\n" +
              "  update_time TIMESTAMP" +
              ") ";

      static  String dbName = "servlet";

    public  static void reCreate()  {
        deleteFile(DerbyUtil.pathToDbDir.toFile());
        Paths.get("derby.log").toFile().delete();
        connection = null;
        try {
            connection = DerbyUtil.getDerbyConnection(dbName, true);
            Statement ps = connection.createStatement();
            ps.execute(createAdmin);
            ps.execute(createUser);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    static  Connection connection = null;

    public  static Connection getConn(){
          if(connection == null){

              try {
                  if(!DerbyUtil.pathToDbDir.toFile().exists()){
//                      connection = DerbyUtil.getDerbyConnection(dbName, true);
                      reCreate();
                  }else {
                      connection = DerbyUtil.getDerbyConnection(dbName, false);
                  }
              } catch (SQLException e) {
                  e.printStackTrace();
              }
          }
        return  connection;
    }

    static String driver = "org.apache.derby.jdbc.ClientDriver";
    static String url = "jdbc:derby://localhost:1527/servlet;create=true";

    public  static Connection getWebConn(){
        if(connection == null) {
            try {
                Class.forName(driver);
                connection = DriverManager.getConnection(url);
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }





    public static void main(String[] args) {
//        reCreate();
//        Connection webConn = getWebConn();
//        System.out.println(webConn);
        System.out.println(createAdmin);
        System.out.println(createUser);
    }


    public static  void deleteFile(File file){
        if (file == null || !file.exists()){
            return;
        }
        File[] files = file.listFiles();
        for (File f: files){
            if (f.isDirectory()){
                deleteFile(f);
            }else {
                f.delete();
            }
        }
        file.delete();
    }





}
