package com.base.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Strings {

	
	public static boolean isEmpty(String str) {
		return str==null?true:"".equals(str.trim());
	}
	
	public static String f2U(String str) {
		return str.substring(0,1).toUpperCase()+str.substring(1);
	}
	
	public static String f2L(String str) {
		return str.substring(0,1).toLowerCase()+str.substring(1);
	}
	
	/**
	 * $index 意味着 你匹配到的是 group的第几组数
	 * 第一个字母 转小写
	 * 最好的办法 是看看 replaceAll 里面有没有 在替换内容里面写代码的 
	 * @param str
	 * @return
	 */
	public static String hump2Breaking(String str) {
		return f2L(str).replaceAll("[A-Z]+", "_$0").toLowerCase();
	}

	private static Pattern linePattern = Pattern.compile("_(\\w)");

	/** 下划线转驼峰 */
	public static String lineToHump(String str) {
		str = str.toLowerCase();
		Matcher matcher = linePattern.matcher(str);
		StringBuffer sb = new StringBuffer();
		while (matcher.find()) {
			matcher.appendReplacement(sb, matcher.group(1).toUpperCase());
		}
		matcher.appendTail(sb);
		return sb.toString();
	}

	public static boolean isNumber(String str) { 
        Pattern pattern = Pattern.compile("(^[\\-0-9][0-9]*(.[0-9]+)?)$"); 
        return pattern.matcher(str).matches(); 
   }
	
	public static void main(String[] args) {

		String create_time = Strings.lineToHump("create_time_");
		System.out.println(create_time);
	}
	
	
}
