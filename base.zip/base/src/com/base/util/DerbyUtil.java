package com.base.util;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Objects;

public class DerbyUtil {

    public final static Path pathToWorkingDir = Paths.get("").toAbsolutePath();
    public final static Path pathToDbDir = pathToWorkingDir.resolve("databases");

    /** Returns an active connection to the database with the provided name, that
     * is assumed to be in the databases directory of the current working directory
     *
     * @param dbName the name of the database, must not be null
     * @return the created Connection
     * @throws SQLException if there was a problem connecting
     */
    public static Connection getDerbyConnection(String dbName) throws SQLException {
        return getDerbyConnection(dbName, false);
    }

    /** Returns an active connection to the database with the provided name, that
     * is assumed to be in the databases directory of the current working directory
     *
     * @param dbName the name of the database, must not be null
     * @param create if true the database is created
     * @return the created Connection
     * @throws SQLException if there was a problem connecting
     */
    public static Connection getDerbyConnection(String dbName, boolean create) throws SQLException {
        Objects.requireNonNull(dbName, "The name of the database was null!");
        // assume the directory is the database directory in project folder
        return getDerbyConnection(pathToDbDir.resolve(dbName), create);
    }

    /** Returns an active connection to the database at the supplied path. Asssumes that
     *  the database already exists
     *
     * @param pathToDb the path to the database, must not be null
     * @return the created Connection
     * @throws SQLException if there was a problem connecting
     */
    public static Connection getDerbyConnection(Path pathToDb) throws SQLException {
        return getDerbyConnection(pathToDb, false);
    }

    /** Returns an active connection to the database at the supplied path
     *
     * @param pathToDb the path to the database, must not be null
     * @param create if true the database is created
     * @return the created Connection
     * @throws SQLException if there was a problem connecting
     */
    public static Connection getDerbyConnection(Path pathToDb, boolean create) throws SQLException {
        Objects.requireNonNull(pathToDb, "The path to the database was null!");
        // create = true means create db if it does not exist, if it already exists a warning is issued
        String dbURL = "jdbc:derby:" + pathToDb.toString();
        if (create){
            dbURL = dbURL + ";create=true";
        }
        System.out.println(dbURL);
        return DriverManager.getConnection(dbURL);
    }

    /** Issues a shutdown command to the database in the databases directory
     *
     * @param dbName the path to the database, must not be null
     */
    public static void shutDownDerby(String dbName)  {
        Objects.requireNonNull(dbName, "The name of the database was null!");
        // assume the directory is the database directory in project folder
        shutDownDerby(pathToDbDir.resolve(dbName));
    }

    /** Issues a shutdown command to the database at the location
     *
     * @param pathToDb the path to the database, must not be null
     */
    public static void shutDownDerby(Path pathToDb) {
        Objects.requireNonNull(pathToDb, "The path to the database was null!");
        // create = true means create db if it does not exist, if it already exists a warning is issued
        String dbURL = "jdbc:derby:" + pathToDb.toString() + ";shutdown=true";
        try {
            DriverManager.getConnection(dbURL);
        } catch (SQLException ex) {
            if ("08006".equals(ex.getSQLState())) {
                System.out.println();
                System.out.println("-----------------------");
                System.out.println("Derby shutdown normally");
            } else {
                printSQLException(ex);
            }
        }
    }

    public static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                if (ignoreSQLException(((SQLException)e).getSQLState()) == false) {
                    e.printStackTrace(System.err);
                    System.err.println("SQLState: " + ((SQLException)e).getSQLState());
                    System.err.println("Error Code: " + ((SQLException)e).getErrorCode());
                    System.err.println("Message: " + e.getMessage());
                    Throwable t = ex.getCause();
                    while (t != null) {
                        System.out.println("Cause: " + t);
                        t = t.getCause();
                    }
                }
            }
        }
    }

    private static boolean ignoreSQLException(String sqlState) {
        if (sqlState == null) {
            System.out.println("The SQL state is not defined!");
            return false;
        }
        // X0Y32: Jar file already exists in schema
        if (sqlState.equalsIgnoreCase("X0Y32"))
            return true;
        // 42Y55: Table already exists in schema
        if (sqlState.equalsIgnoreCase("42Y55"))
            return true;
        return false;
    }
}