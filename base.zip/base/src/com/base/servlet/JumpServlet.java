package com.base.servlet;

import com.base.bean.Admin;
import com.base.util.SessionContext;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/jump",name = "jump")
public class JumpServlet extends  CommonServlet {
    @Override
    void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if(action.equals("toIndex")){
            Admin admin = (Admin) SessionContext.isLogin(req);
            if(admin!=null){
                req.setAttribute("admin",admin);
                req.getRequestDispatcher("/index.jsp").forward(req,resp);
            }else {
                resp.sendRedirect("/jump?action=toLogin");
            }
        }else if(action.equals("toLogin")){
            req.getRequestDispatcher("/login.jsp").forward(req,resp);
        }else if(action.equals("toAdminList")){
            req.getRequestDispatcher("/admin/adminList.jsp").forward(req,resp);
        }else if(action.equals("toAdminAdd")){
            req.getRequestDispatcher("/admin/adminAdd.jsp").forward(req,resp);
        }else if(action.equals("toUserList")){
            req.getRequestDispatcher("/user/userList.jsp").forward(req,resp);
        }else if(action.equals("toUserAdd")){
            req.getRequestDispatcher("/user/userAdd.jsp").forward(req,resp);
        }else if(action.equals("logout")){
            SessionContext.logout(req);
            req.getRequestDispatcher("/login.jsp").forward(req,resp);
        }
    }
}
