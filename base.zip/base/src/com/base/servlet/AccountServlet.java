package com.base.servlet;

import com.base.bean.Account;
import com.base.dao.AccountDao;
import com.base.util.ResultBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Map;

@WebServlet(urlPatterns="/user")
public class AccountServlet extends CommonServlet {

   static AccountDao accountDao = new AccountDao();

    @Override
    void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if(action.equals("query")){
            String p =  req.getParameter("page");
            String s =  req.getParameter("size");
            String  input = req.getParameter("input");
            Map<String, Object> map = accountDao.query(input, Integer.valueOf(p), Integer.valueOf(s));
            out(resp,ResultBean.ok(map));
        }else  if(action.equals("delete")){
            String id =  req.getParameter("id");
            accountDao.delete(Long.valueOf(id));
            out(resp,ResultBean.ok());
        }else  if(action.equals("batchDelete")){
            String ids =  req.getParameter("ids");
            String[] datas = ids.split(",");
            for (String id : datas) {
                accountDao.delete(Long.valueOf(id));
            }
            out(resp,ResultBean.ok());
        }else  if(action.equals("update")){
            String id =  req.getParameter("id");
            String name =  req.getParameter("name");
            String phone =  req.getParameter("phone");
            String address =  req.getParameter("address");
            Account account = new Account();
            account.setId(Long.valueOf(id));
            account.setName(name);
            account.setPhone(phone);
            account.setAddress(address);
            account.setUpdateTime(Timestamp.valueOf(LocalDateTime.now()));
            accountDao.update(account);
            out(resp,ResultBean.ok());
        }else if(action.equals("add")){
            String name =  req.getParameter("name");
            String phone =  req.getParameter("phone");
            String address =  req.getParameter("address");
            Account account = new Account();
            account.setName(name);
            account.setPhone(phone);
            account.setAddress(address);
            account.setUpdateTime(Timestamp.valueOf(LocalDateTime.now()));
            account.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
            accountDao.add(account);
            out(resp,ResultBean.ok());
        }
    }

}
