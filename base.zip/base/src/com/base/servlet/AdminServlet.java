package com.base.servlet;

import com.base.bean.Admin;
import com.base.dao.AdminDao;
import com.base.util.ResultBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@WebServlet(urlPatterns="/admin")
public class AdminServlet extends CommonServlet {

   static AdminDao adminDao = new AdminDao();

    @Override
    void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if(action.equals("query")){
            String p =  req.getParameter("page");
            String s =  req.getParameter("size");
            String  input = req.getParameter("input");
            Map<String, Object> map = adminDao.query(input, Integer.valueOf(p), Integer.valueOf(s));
            out(resp,ResultBean.ok(map));
        }else  if(action.equals("delete")){
            String id =  req.getParameter("id");
            adminDao.delete(Long.valueOf(id));
            out(resp,ResultBean.ok());
        }else  if(action.equals("batchDelete")){
            String ids =  req.getParameter("ids");
            String[] datas = ids.split(",");
            for (String id : datas) {
                adminDao.delete(Long.valueOf(id));
            }
            out(resp,ResultBean.ok());
        }else  if(action.equals("update")){
            String id =  req.getParameter("id");
            String username =  req.getParameter("username");
            String pwd =  req.getParameter("pwd");
            Admin admin = new Admin();
            admin.setId(Long.valueOf(id));
            admin.setUsername(username);
            admin.setPwd(pwd);
            admin.setUpdateTime(Timestamp.valueOf(LocalDateTime.now()));
            adminDao.update(admin);
            out(resp,ResultBean.ok());
        }else if(action.equals("add")){
            String username =  req.getParameter("username");
            String pwd =  req.getParameter("pwd");
            Admin admin = new Admin();
            admin.setUsername(username);
            admin.setPwd(pwd);
            admin.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
            admin.setUpdateTime(Timestamp.valueOf(LocalDateTime.now()));
            adminDao.add(admin);
            out(resp,ResultBean.ok());
        }
    }

}
