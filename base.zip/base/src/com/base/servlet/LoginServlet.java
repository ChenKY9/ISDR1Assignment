package com.base.servlet;

import com.alibaba.fastjson.JSON;
import com.base.bean.Admin;
import com.base.dao.AdminDao;
import com.base.util.Msg;
import com.base.util.ResultBean;
import com.base.util.SessionContext;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/login",name = "login")
public class LoginServlet extends CommonServlet {
    static AdminDao adminDao = new AdminDao();

    @Override
    void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name =  req.getParameter("name");
        String pwd =  req.getParameter("pwd");
        String code =  req.getParameter("code");
        if (!code.equalsIgnoreCase(SessionContext.getIdentifyCode(req))) {
//            resp.getWriter().print(ResultBean.msg(Msg.C400_001));
            out(resp,ResultBean.msg(Msg.C400_001));
        }
        Admin admin = new Admin();
        admin.setUsername(name);
        admin.setPwd(pwd);
        Admin result = adminDao.queryOne(admin);
        if(result == null){
//            resp.getWriter().print(ResultBean.msg(Msg.C400_004));
            out(resp,ResultBean.msg(Msg.C400_004));
        }
        SessionContext.setLoginUser(req, result);
        out(resp,ResultBean.ok(result));
    }

}
