package com.base.bean;
import java.io.Serializable;
import java.sql.Timestamp;

public class Admin implements Serializable{
        private static final long serialVersionUID = 1L;
        
	     private Long id;
	     private String username;
	     private String pwd;
	     private Timestamp createTime;
	     private Timestamp updateTime;            

        public Long getId(){
            return this.id;
        }
        
        public void setId(Long id){
              this.id = id;
        }   
        public String getUsername(){
            return this.username;
        }
        
        public void setUsername(String username){
              this.username = username;
        }   
        public String getPwd(){
            return this.pwd;
        }
        
        public void setPwd(String pwd){
              this.pwd = pwd;
        }   
        public Timestamp getCreateTime(){
            return this.createTime;
        }
        
        public void setCreateTime(Timestamp createTime){
              this.createTime = createTime;
        }   
        public Timestamp getupdateTime(){
            return this.updateTime;
        }
        
        public void setUpdateTime(Timestamp updateTime){
              this.updateTime = updateTime;
        }   

          
        public String toString(){
        String str = "";
        str += "id:"+id; 
        str+=",";
        str += "username:"+username; 
        str+=",";
        str += "pwd:"+pwd; 
        str+=",";
        str += "createTime:"+createTime.toString(); 
        str+=",";
        str += "updateTime:"+updateTime.toString(); 
          return str;   
        }









}