package com.base.bean;

import java.sql.Timestamp;
import java.util.Date;
import java.io.Serializable;

public class Account implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;
    private String name;
    private String phone;
    private String address;
    private Timestamp createTime;
    private Timestamp updateTime;

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Timestamp getCreateTime() {
        return this.createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }


    public String toString() {
        String str = "";
        str += "id:" + id;
        str += ",";
        str += "name:" + name;
        str += ",";
        str += "phone:" + phone;
        str += ",";
        str += "address:" + address;
        str += ",";
        str += "createTime:" + createTime;
        str += ",";
        str += "updateTime:" + updateTime;
        return str;
    }


}